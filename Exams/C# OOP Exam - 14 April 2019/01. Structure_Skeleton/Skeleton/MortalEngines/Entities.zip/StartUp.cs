﻿namespace MortalEngines
{
    using MortalEngines.Common;
    using MortalEngines.Core;

    public class StartUp
    {
        public static void Main()
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}