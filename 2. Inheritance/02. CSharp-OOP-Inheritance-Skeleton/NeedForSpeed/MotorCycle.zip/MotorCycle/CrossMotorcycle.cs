﻿namespace NeedForSpeed.MotorCycle
{
    public class CrossMotorcycle : Motorcycle
    {
        public CrossMotorcycle(int horsePower, double fuel) 
            : base(horsePower, fuel)
        {

        }
    }
}
