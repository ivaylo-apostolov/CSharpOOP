﻿using System;

using ShoppingSpree.Core;

namespace ShoppingSpree
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
