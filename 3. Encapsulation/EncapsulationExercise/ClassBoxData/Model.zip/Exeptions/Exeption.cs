﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassBoxData.Exeptions
{
    public static class Exeption
    {
        public static string LenthCannotBeNegativeOrZero = "Length cannot be zero or negative.";

        public static string WidthCannotBeNegativeOrZero = "Width cannot be zero or negative.";

        public static string HeightCannotBeNegativeOrZero = "Height cannot be zero or negative.";
    }
}
